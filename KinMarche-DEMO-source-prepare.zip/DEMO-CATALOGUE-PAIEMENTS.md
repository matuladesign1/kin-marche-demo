# Kin Marché DEMO — catalogue et paiement

Cette archive est une base de démonstration isolée. Elle ne contient aucune donnée commerciale réelle de Kin Marché.

## Catalogue livré
- Catégories multilingues et 17 fiches produits de démonstration.
- Descriptions, marques/conditionnements indicatifs, images, références internes, prix et stocks d'exemple.
- Un seul magasin virtuel `DEMO-KIN-001`, sans adresse ni coordonnées GPS inventées.
- Trois codes GTIN fabricant recoupés publiquement : Coca-Cola 1,5 L `5449000000439`, Nido 400 g `6001068705504`, Nescafé Classic 100 g `7891000254912`.
- Les autres codes `290...` sont des EAN-13 synthétiques internes pour tester le scanner. Ils ne sont pas des codes fabricant et ne doivent jamais être publiés comme références réelles.
- Les prix, stocks, descriptions et images non sourcées sont des exemples de démonstration. Les photos génériques ne garantissent pas le conditionnement vendu en magasin.

## Paiement
L'écran DEMO affiche Orange Money, M-Pesa, Airtel Money, Afrimoney, Visa et Mastercard. Le parcours DEMO simule localement le résultat : aucun prestataire, débit, PIN ou webhook réel n'est appelé. Le paiement réel nécessite un contrat et un adaptateur sécurisé d'un agrégateur agréé, avec secrets conservés côté serveur.

## Installer le backend DEMO depuis GitHub Actions
Ajouter dans Settings → Secrets and variables → Actions :
- `DEMO_SUPABASE_URL` = `https://jshkcaunoxjnybnvausk.supabase.co`
- `DEMO_SUPABASE_ANON_KEY` = clé publique/anon du projet Kin-marche-demo
- `DEMO_SUPABASE_DB_PASSWORD` = mot de passe de base de données de CE projet DEMO
- `SUPABASE_ACCESS_TOKEN` = token d'accès personnel Supabase

Extraire le contenu de cette archive à la racine du dépôt GitHub, en conservant `.github/`, `apps/` et `supabase/`. Le workflow `APK Android — DEMO commerciale` appliquera les migrations du projet DEMO, puis compilera et publiera l'APK. Ne jamais ajouter une clé `service_role` dans l'application ou dans le dépôt.

## Avant de présenter comme catalogue officiel
Faire valider par Kin Marché les produits réellement vendus, codes-barres lus sur les emballages, photos officielles, prix, stocks, unités, magasins et catalogues promotionnels datés. Importer ensuite les données officielles via l'administration ou un import contrôlé.
