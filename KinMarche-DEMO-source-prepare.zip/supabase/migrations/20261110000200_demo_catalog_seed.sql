-- KIN MARCHÉ DEMO : catalogue fictif de présentation uniquement.
-- Les tarifs et stocks sont des exemples, PAS les tarifs/stock réels de Kin Marché.
-- Seuls trois GTIN fabricant ont été recoupés publiquement (Coca-Cola, Nido, Nescafé).
-- Tous les codes 290... sont des EAN-13 internes de démo, ne pas utiliser en production.
-- Les photos de produits génériques sont illustratives. Vérifier les références locales, emballages et droits des images.
insert into public.product_categories (slug,name,icon,sort_order) values
('boissons', jsonb_build_object('fr','Boissons','en','Drinks','ln','Masanga','sw','Vinywaji'),'cup',1),
('epicerie', jsonb_build_object('fr','Épicerie','en','Groceries','ln','Biloko ya kolia','sw','Vyakula'),'shopping-basket',2),
('produits-laitiers', jsonb_build_object('fr','Produits laitiers','en','Dairy','ln','Biloko ya miliki','sw','Bidhaa za maziwa'),'milk',3),
('entretien', jsonb_build_object('fr','Entretien maison','en','Home care','ln','Kosukola ndako','sw','Usafi wa nyumbani'),'sparkles',4),
('hygiene-beaute', jsonb_build_object('fr','Hygiène & beauté','en','Health & beauty','ln','Bopeto','sw','Afya na urembo'),'heart',5),
('petit-dejeuner', jsonb_build_object('fr','Petit-déjeuner','en','Breakfast','ln','Bilei ya ntongo','sw','Kifungua kinywa'),'coffee',6),
('conserves', jsonb_build_object('fr','Conserves','en','Canned food','ln','Bilei ya bibombelo','sw','Vyakula vya makopo'),'package',7),
('boulangerie', jsonb_build_object('fr','Boulangerie','en','Bakery','ln','Mapa','sw','Mkate'),'croissant',8),
('bebe', jsonb_build_object('fr','Bébé','en','Baby','ln','Mwana moke','sw','Mtoto'),'baby',9)
on conflict (slug) do update set name=excluded.name,icon=excluded.icon,sort_order=excluded.sort_order,is_active=true;

insert into public.stores (code,name,province,city,commune,landmark,address_verified,is_open,is_active,delivery_radius_km,delivery_fee_usd,avg_prep_minutes,delivery_zone)
values ('DEMO-KIN-001','Kin Marché — Magasin virtuel DEMO','Kinshasa','Kinshasa','Kinshasa','Point de vente virtuel de démonstration — adresse non réelle',false,true,true,20,1.50,25,'{"Kinshasa":true}'::jsonb)
on conflict (code) do update set name=excluded.name,is_active=true,is_open=true,address_verified=false,delivery_zone=excluded.delivery_zone;

with cats as (select slug,id from public.product_categories),
p(sku,barcode,name,description,cat,brand,unit,size,price,stock,photo,featured,barcode_type) as (values
('DEMO-BOI-001','5449000000439','Coca-Cola Original Taste 1,5 L','Boisson gazeuse Coca-Cola Original Taste, bouteille PET 1,5 litre.','boissons','Coca-Cola','litre',1.5,1.8,80,'https://images.openfoodfacts.org/images/products/544/900/000/0439/front_en.3.400.jpg',true,'manufacturer_gtin'),
('DEMO-LAI-001','6001068705504','Nestlé Nido 400 g','Lait en poudre Nido, boîte de 400 g. Vérifier la variante exacte sur l’emballage.','produits-laitiers','Nestlé Nido','g',400,5.5,35,'https://images.openfoodfacts.org/images/products/600/106/870/5504/front_en.3.400.jpg',true,'manufacturer_gtin'),
('DEMO-CAF-001','7891000254912','Nescafé Classic 100 g','Café soluble Nescafé Classic, pot de 100 g.','petit-dejeuner','Nescafé','g',100,4.5,30,'https://images.openfoodfacts.org/images/products/789/100/025/4912/front_en.3.400.jpg',true,'manufacturer_gtin'),
('DEMO-BOI-002','2900000000018','Fanta Orange 1,5 L','Boisson gazeuse aromatisée à l’orange, bouteille 1,5 litre.','boissons','Fanta','litre',1.5,1.8,60,'https://images.unsplash.com/photo-1624517452488-04869289c4ca?auto=format&fit=crop&w=700&q=85',false,'internal_demo_ean13'),
('DEMO-BOI-003','2900000000025','Eau minérale 1,5 L','Eau minérale, bouteille de 1,5 litre. Marque et source locale à confirmer.','boissons','Eau minérale','litre',1.5,0.8,120,'https://images.unsplash.com/photo-1560023907-5f339617ea30?auto=format&fit=crop&w=700&q=85',false,'internal_demo_ean13'),
('DEMO-EPI-001','2900000000032','Riz parfumé 25 kg','Sac de riz parfumé, format familial 25 kg. Marque à confirmer.','epicerie','Riz','kg',25,32.0,25,'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=700&q=85',true,'internal_demo_ean13'),
('DEMO-EPI-002','2900000000049','Spaghetti 500 g','Pâtes alimentaires spaghetti, paquet de 500 g.','epicerie','Pâtes alimentaires','g',500,1.2,100,'https://images.unsplash.com/photo-1551462147-ff29053bfc14?auto=format&fit=crop&w=700&q=85',false,'internal_demo_ean13'),
('DEMO-EPI-003','2900000000056','Huile végétale 5 L','Bidon d’huile végétale, format 5 litres. Type et marque à confirmer.','epicerie','Huile végétale','litre',5,12.0,22,'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?auto=format&fit=crop&w=700&q=85',true,'internal_demo_ean13'),
('DEMO-ENT-001','2900000000063','Lessive en poudre 3 kg','Détergent en poudre pour lavage du linge, paquet de 3 kg. Marque à confirmer.','entretien','Lessive','kg',3,8.0,20,'https://images.unsplash.com/photo-1605276374104-dee2a0ed3cd6?auto=format&fit=crop&w=700&q=85',false,'internal_demo_ean13'),
('DEMO-CON-001','2900000000070','Sardines à la tomate 125 g','Sardines en conserve à la sauce tomate, boîte de 125 g.','conserves','Conserve de poisson','g',125,1.3,50,'https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?auto=format&fit=crop&w=700&q=85',false,'internal_demo_ean13'),
('DEMO-EPI-004','2900000000087','Cubes d’assaisonnement — paquet','Cubes d’assaisonnement pour la cuisine, paquet de démonstration. Marque à confirmer.','epicerie','Assaisonnement','pack',1,1.5,75,'https://images.unsplash.com/photo-1604908176997-125f25cc6f3d?auto=format&fit=crop&w=700&q=85',false,'internal_demo_ean13'),
('DEMO-EPI-005','2900000000094','Sucre en poudre 5 kg','Sucre blanc cristallisé, sac de 5 kg.','epicerie','Sucre','kg',5,6.5,30,'https://images.unsplash.com/photo-1581441363689-1f3c3c414635?auto=format&fit=crop&w=700&q=85',false,'internal_demo_ean13'),
('DEMO-HYG-001','2900000000100','Savon de toilette 100 g','Savon de toilette, pain de 100 g. Marque à confirmer.','hygiene-beaute','Savon','g',100,1.5,45,'https://images.unsplash.com/photo-1600857544200-b2f666a9a2ec?auto=format&fit=crop&w=700&q=85',false,'internal_demo_ean13'),
('DEMO-HYG-002','2900000000117','Dentifrice 100 ml','Dentifrice, tube de 100 ml. Marque à confirmer.','hygiene-beaute','Dentifrice','ml',100,2.0,40,'https://images.unsplash.com/photo-1609840114035-3c981b782dfe?auto=format&fit=crop&w=700&q=85',false,'internal_demo_ean13'),
('DEMO-EPI-006','2900000000124','Farine de maïs (fufu) 1 kg','Farine de maïs pour préparation de fufu, paquet de 1 kg.','epicerie','Farine de maïs','kg',1,2.2,40,'https://images.unsplash.com/photo-1601593768791-2e6a6d5d0f58?auto=format&fit=crop&w=700&q=85',true,'internal_demo_ean13'),
('DEMO-BEB-001','2900000000131','Céréales infantiles 400 g','Céréales infantiles, format de démonstration 400 g. Vérifier l’âge indiqué et l’étiquette avant commercialisation.','bebe','Céréales infantiles','g',400,6.0,20,'https://images.unsplash.com/photo-1516627145497-ae6968895b74?auto=format&fit=crop&w=700&q=85',false,'internal_demo_ean13'),
('DEMO-BOU-001','2900000000148','Pain de mie 500 g','Pain de mie emballé, format 500 g. Marque et fraîcheur à confirmer.','boulangerie','Pain','g',500,2.5,20,'https://images.unsplash.com/photo-1598373182133-52452f7691ef?auto=format&fit=crop&w=700&q=85',false,'internal_demo_ean13')
)
insert into public.products (sku,barcode,name,description,category_id,brand,unit,unit_size,specs,is_featured,is_active)
select p.sku,p.barcode,p.name,p.description,c.id,p.brand,p.unit::public.sale_unit,p.size,
jsonb_build_object('demo_catalog',true,'barcode_type',p.barcode_type,'photo_note','Visuel de démonstration : vérifier la photo exacte du conditionnement vendu en magasin'),p.featured,true
from p join cats c on c.slug=p.cat
on conflict (sku) do update set barcode=excluded.barcode,name=excluded.name,description=excluded.description,category_id=excluded.category_id,brand=excluded.brand,unit=excluded.unit,unit_size=excluded.unit_size,specs=excluded.specs,is_featured=excluded.is_featured,is_active=true;

with p(sku,photo,name) as (values
('DEMO-BOI-001','https://images.openfoodfacts.org/images/products/544/900/000/0439/front_en.3.400.jpg','Coca-Cola Original Taste 1,5 L'),
('DEMO-LAI-001','https://images.openfoodfacts.org/images/products/600/106/870/5504/front_en.3.400.jpg','Nestlé Nido 400 g'),
('DEMO-CAF-001','https://images.openfoodfacts.org/images/products/789/100/025/4912/front_en.3.400.jpg','Nescafé Classic 100 g'),
('DEMO-BOI-002','https://images.unsplash.com/photo-1624517452488-04869289c4ca?auto=format&fit=crop&w=700&q=85','Fanta Orange 1,5 L'),
('DEMO-BOI-003','https://images.unsplash.com/photo-1560023907-5f339617ea30?auto=format&fit=crop&w=700&q=85','Eau minérale 1,5 L'),
('DEMO-EPI-001','https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=700&q=85','Riz parfumé 25 kg'),
('DEMO-EPI-002','https://images.unsplash.com/photo-1551462147-ff29053bfc14?auto=format&fit=crop&w=700&q=85','Spaghetti 500 g'),
('DEMO-EPI-003','https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?auto=format&fit=crop&w=700&q=85','Huile végétale 5 L'),
('DEMO-ENT-001','https://images.unsplash.com/photo-1605276374104-dee2a0ed3cd6?auto=format&fit=crop&w=700&q=85','Lessive en poudre 3 kg'),
('DEMO-CON-001','https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?auto=format&fit=crop&w=700&q=85','Sardines à la tomate 125 g'),
('DEMO-EPI-004','https://images.unsplash.com/photo-1604908176997-125f25cc6f3d?auto=format&fit=crop&w=700&q=85','Cubes d’assaisonnement — paquet'),
('DEMO-EPI-005','https://images.unsplash.com/photo-1581441363689-1f3c3c414635?auto=format&fit=crop&w=700&q=85','Sucre en poudre 5 kg'),
('DEMO-HYG-001','https://images.unsplash.com/photo-1600857544200-b2f666a9a2ec?auto=format&fit=crop&w=700&q=85','Savon de toilette 100 g'),
('DEMO-HYG-002','https://images.unsplash.com/photo-1609840114035-3c981b782dfe?auto=format&fit=crop&w=700&q=85','Dentifrice 100 ml'),
('DEMO-EPI-006','https://images.unsplash.com/photo-1601593768791-2e6a6d5d0f58?auto=format&fit=crop&w=700&q=85','Farine de maïs (fufu) 1 kg'),
('DEMO-BEB-001','https://images.unsplash.com/photo-1516627145497-ae6968895b74?auto=format&fit=crop&w=700&q=85','Céréales infantiles 400 g'),
('DEMO-BOU-001','https://images.unsplash.com/photo-1598373182133-52452f7691ef?auto=format&fit=crop&w=700&q=85','Pain de mie 500 g')
)
insert into public.product_images (product_id,url,alt,sort_order)
select pr.id,p.photo,'Image illustrative — '||p.name,0 from p join public.products pr on pr.sku=p.sku
where not exists (select 1 from public.product_images pi where pi.product_id=pr.id and pi.url=p.photo);

with v(sku,price,stock) as (values
('DEMO-BOI-001',1.8,80),
('DEMO-LAI-001',5.5,35),
('DEMO-CAF-001',4.5,30),
('DEMO-BOI-002',1.8,60),
('DEMO-BOI-003',0.8,120),
('DEMO-EPI-001',32.0,25),
('DEMO-EPI-002',1.2,100),
('DEMO-EPI-003',12.0,22),
('DEMO-ENT-001',8.0,20),
('DEMO-CON-001',1.3,50),
('DEMO-EPI-004',1.5,75),
('DEMO-EPI-005',6.5,30),
('DEMO-HYG-001',1.5,45),
('DEMO-HYG-002',2.0,40),
('DEMO-EPI-006',2.2,40),
('DEMO-BEB-001',6.0,20),
('DEMO-BOU-001',2.5,20)
)
insert into public.store_inventory (store_id,product_id,price_usd,stock,is_available)
select s.id,p.id,v.price,v.stock,true from v join public.products p on p.sku=v.sku join public.stores s on s.code='DEMO-KIN-001'
on conflict (store_id,product_id) do update set price_usd=excluded.price_usd,stock=excluded.stock,is_available=true;

update public.app_settings set value=jsonb_set(value,'{enabled_methods}','["orange_money","mpesa","airtel_money","afrimoney","visa","mastercard"]'::jsonb,true) where key='payments';
