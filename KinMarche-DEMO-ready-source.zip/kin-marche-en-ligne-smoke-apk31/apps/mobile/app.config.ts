import type { ExpoConfig } from 'expo/config';
import fs from 'node:fs';

// Configuration dynamique : les clés propres à l'appareil Android (Google Maps, Firebase)
// sont injectées au moment du build (secrets GitHub), jamais écrites dans le dépôt.
const demoBuild = process.env.DEMO_BUILD === 'true';

const base = {
  "name": demoBuild ? "Kin Marché — DEMO" : "Kin Marché en ligne",
  "slug": "kin-marche-en-ligne",
  "scheme": demoBuild ? "kinmarche-demo" : "kinmarche",
  "version": "2.0.0",
  "orientation": "portrait",
  "icon": "./assets/images/icon.png",
  "userInterfaceStyle": "automatic",
  "description": "Supermarché en ligne en RDC — Au prix du Grand Marché",
  "splash": {
    "image": "./assets/images/splash-logo.png",
    "resizeMode": "contain",
    "backgroundColor": "#FFFFFF"
  },
  "ios": {
    "supportsTablet": true,
    "bundleIdentifier": demoBuild ? "cd.kinmarche.enligne.demo" : "cd.kinmarche.enligne",
    "infoPlist": {
      "NSCameraUsageDescription": "La caméra sert à scanner le code-barres d'un produit.",
      "NSLocationWhenInUseUsageDescription": "Votre position sert à trouver le supermarché Kin Marché qui peut vous livrer.",
      "NSMicrophoneUsageDescription": "Le micro sert à rechercher un produit à la voix.",
      "NSPhotoLibraryUsageDescription": "Vos photos servent à rechercher un produit ou à joindre un document."
    }
  },
  "android": {
    "package": demoBuild ? "cd.kinmarche.enligne.demo" : "cd.kinmarche.enligne",
    "adaptiveIcon": {
      "foregroundImage": "./assets/images/adaptive-icon.png",
      "backgroundImage": "./assets/images/adaptive-icon-background.png",
      "monochromeImage": "./assets/images/adaptive-icon-monochrome.png",
      "backgroundColor": "#F5F5F3"
    },
    "permissions": [
      "CAMERA",
      "ACCESS_COARSE_LOCATION",
      "ACCESS_FINE_LOCATION",
      "RECORD_AUDIO",
      "REQUEST_INSTALL_PACKAGES",
      "VIBRATE",
      "WAKE_LOCK"
    ]
  },
  "web": {
    "bundler": "metro",
    "output": "single",
    "favicon": "./assets/images/favicon.png"
  },
  "plugins": [
    "expo-router",
    [
      "expo-camera",
      {
        "cameraPermission": "La caméra sert à scanner le code-barres d'un produit."
      }
    ],
    [
      "expo-location",
      {
        "locationWhenInUsePermission": "Votre position sert à trouver le supermarché Kin Marché qui peut vous livrer."
      }
    ],
    [
      "expo-notifications",
      {
        "icon": "./assets/images/notification-icon.png",
        "color": "#1CB7B8",
        "sounds": ["./assets/sounds/appel_mission.wav"]
      }
    ],
    "expo-localization",
    [
      "expo-splash-screen",
      {
        "image": "./assets/images/splash-logo.png",
        "imageWidth": 220,
        "resizeMode": "contain",
        "backgroundColor": "#FFFFFF"
      }
    ],
    [
      "expo-speech-recognition",
      {
        "microphonePermission": "Le micro sert à rechercher un produit à la voix.",
        "speechRecognitionPermission": "La reconnaissance vocale sert à rechercher un produit à la voix.",
        "androidSpeechServicePackages": [
          "com.google.android.googlequicksearchbox"
        ]
      }
    ]
  ],
  "experiments": {
    "typedRoutes": false
  },
  "extra": {
    "developer": "MATULA DESIGN",
    "demoMode": demoBuild
  }
} as ExpoConfig;

// Numéro de build : celui du workflow GitHub (APK n°…), toujours croissant → mise à jour par-dessus l'ancienne version.
const buildNumber = Number(process.env.GITHUB_RUN_NUMBER ?? process.env.BUILD_NUMBER ?? '') || undefined;
const mapsKey = process.env.GOOGLE_MAPS_ANDROID_KEY;
const googleServices = process.env.GOOGLE_SERVICES_JSON_PATH;
const easProjectId = process.env.EAS_PROJECT_ID;

const config: ExpoConfig = {
  ...base,
  android: {
    ...base.android,
    ...(buildNumber ? { versionCode: buildNumber } : {}),
    ...(googleServices && fs.existsSync(googleServices) ? { googleServicesFile: googleServices } : {}),
    config: { ...(base.android?.config ?? {}), ...(mapsKey ? { googleMaps: { apiKey: mapsKey } } : {}) },
  },
  extra: {
    ...base.extra,
    buildNumber: buildNumber ?? null,
    // Ancienne carte Google (plus utilisée : la carte Kin Marché fonctionne sans clé Google).
    mapsEnabled: { android: !!mapsKey, ios: true, web: false },
    // Fond de la carte Kin Marché (OpenStreetMap par défaut). Pour un autre fournisseur de tuiles
    // (MapTiler, CARTO… avec leur clé gratuite) : MAP_TILES_URL avec {z}/{x}/{y} et MAP_ATTRIBUTION.
    mapTilesUrl: process.env.MAP_TILES_URL ?? null,
    mapAttribution: process.env.MAP_ATTRIBUTION ?? null,
    ...(easProjectId ? { eas: { projectId: easProjectId } } : {}),
  },
};

export default config;
