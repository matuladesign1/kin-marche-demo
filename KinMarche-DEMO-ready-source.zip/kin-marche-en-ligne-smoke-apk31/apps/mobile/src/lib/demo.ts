import Constants from 'expo-constants';

/** Activé uniquement dans l'APK DEMO compilé avec DEMO_BUILD=true. */
export const DEMO_MODE = Constants.expoConfig?.extra?.demoMode === true;
