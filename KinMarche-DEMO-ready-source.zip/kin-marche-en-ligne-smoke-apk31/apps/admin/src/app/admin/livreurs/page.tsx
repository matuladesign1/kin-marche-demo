import { revalidatePath } from 'next/cache';
import { requirePermission } from '@/lib/auth';
import { redirect } from 'next/navigation';
import { CertifiedDriver } from '@/components/icons';
import { Flash } from '@/components/Shell';
import { dateTime } from '@/lib/format';
import { supabaseServer } from '@/lib/supabase-server';

const STATUS: Record<string, { label: string; cls: string }> = {
  pending_review: { label: 'À vérifier', cls: 'warn' },
  verified: { label: 'Certifié', cls: 'ok' },
  suspended: { label: 'Suspendu', cls: 'bad' },
  rejected: { label: 'Refusé', cls: 'bad' },
};
const DOC: Record<string, string> = { id_photo: 'Pièce d’identité', vehicle_registration: 'Document du véhicule', license: 'Permis', other: 'Autre' };
const TRANSPORT: Record<string, string> = { foot: 'À pied', bicycle: 'Vélo', motorbike: 'Moto', car: 'Voiture', van: 'Camionnette', truck: 'Camion' };

async function decide(formData: FormData, status: 'verified' | 'suspended' | 'rejected') {
  'use server';
  const sb = await supabaseServer();
  const { error } = await sb.rpc('review_driver', {
    p_driver_id: String(formData.get('id')), p_status: status, p_note: String(formData.get('note') ?? '').trim() || null,
  });
  revalidatePath('/admin/livreurs');
  redirect(`/admin/livreurs?f=${formData.get('f') ?? 'pending_review'}&${error ? 'err=' + encodeURIComponent(error.message) : 'ok=Décision enregistrée et notifiée au livreur'}`);
}
// Une action par bouton : la décision ne dépend pas de la valeur du bouton cliqué (non transmise par certains navigateurs).
async function certify(formData: FormData) { 'use server'; await decide(formData, 'verified'); }
async function suspend(formData: FormData) { 'use server'; await decide(formData, 'suspended'); }
async function reject(formData: FormData) { 'use server'; await decide(formData, 'rejected'); }
// Touche Entrée dans le champ note : aucune décision.
async function noDecision() { 'use server'; }

// Test d'appel (administrateur général) : le téléphone du livreur sonne comme pour une vraie course, sans commande.
async function callTest(formData: FormData) {
  'use server';
  const sb = await supabaseServer();
  const name = String(formData.get('name') ?? 'le livreur');
  const { error } = await sb.rpc('send_call_test', { p_driver: String(formData.get('id')) });
  revalidatePath('/admin/livreurs');
  redirect(`/admin/livreurs?f=${formData.get('f') ?? 'pending_review'}&${error
    ? 'err=' + encodeURIComponent(error.message === 'NOT_A_DRIVER' ? 'Ce compte n’est pas un livreur.' : error.message)
    : 'ok=' + encodeURIComponent(`Appel de test envoyé à ${name} : son téléphone sonne pendant 60 s. Sa réponse s’affiche dans « Tests d’appel » (bouton Actualiser).`)}#tests`);
}

const TEST_STATUS: Record<string, { label: string; cls: string }> = {
  sent: { label: 'Sonne… (pas encore vu)', cls: 'warn' },
  shown: { label: 'Appel affiché, en attente de réponse', cls: 'warn' },
  accepted: { label: 'Accepté — l’appel fonctionne', cls: 'ok' },
  declined: { label: 'Refusé — l’appel fonctionne', cls: 'ok' },
  expired: { label: 'Sans réponse', cls: 'bad' },
};

// Un client devient livreur « à vérifier » : il complète ensuite son dossier dans l'application.
async function makeDriver(formData: FormData) {
  'use server';
  const sb = await supabaseServer();
  const { error } = await sb.rpc('staff_make_driver', { p_email: String(formData.get('email') ?? '').trim() });
  const messages: Record<string, string> = {
    USER_NOT_FOUND: "Aucun compte avec cet e-mail : la personne doit d'abord créer son compte dans l'application.",
    ROLE_CONFLICT: 'Ce compte a déjà un autre rôle (directeur, agent ou administrateur).',
  };
  revalidatePath('/admin/livreurs');
  redirect(`/admin/livreurs?${error ? 'err=' + encodeURIComponent(messages[error.message] ?? error.message) : 'ok=' + encodeURIComponent('Espace livreur ouvert : la personne complète son dossier dans l’application')}`);
}

export default async function Livreurs({ searchParams }: { searchParams: Promise<{ f?: string; ok?: string; err?: string }> }) {
  const user = await requirePermission('drivers');
  const sp = await searchParams;
  const f = STATUS[sp.f ?? ''] ? sp.f! : 'pending_review';
  const sb = await supabaseServer();
  const { data: drivers } = await sb.from('drivers')
    .select('id, driver_code, status, province, city, address, zone_communes, emergency_contact_name, emergency_contact_phone, payout_method, payout_account_masked, is_available, verified_at, rating, rating_count, created_at, profiles(full_name, email, phone, avatar_url), driver_vehicles(mode, plate_number, max_weight_kg), driver_documents(id, doc_type, storage_path, status, created_at)')
    .eq('status', f).order('created_at', { ascending: true });

  // Derniers tests d'appel (administrateur général).
  const { data: tests } = user.isSuper
    ? await sb.from('driver_call_tests')
      .select('id, status, created_at, shown_at, answered_at, profiles!driver_call_tests_driver_id_fkey(full_name, phone)')
      .order('created_at', { ascending: false }).limit(10)
    : { data: null };
  const nowMs = Date.now();

  // Documents d'identité : bucket privé, liens signés valables 10 minutes, visibles par l'admin uniquement.
  const paths = (drivers ?? []).flatMap((d: any) => (d.driver_documents ?? []).map((x: any) => x.storage_path));
  const signed: Record<string, string> = {};
  if (paths.length) {
    const { data } = await sb.storage.from('driver-documents').createSignedUrls(paths, 600);
    (data ?? []).forEach((s) => { if (s.path && s.signedUrl) signed[s.path] = s.signedUrl; });
  }

  return (
    <>
      <h1>Livreurs</h1>
      <p className="page-sub">Candidatures, certification et suivi des livreurs de votre zone.</p>
      <Flash ok={sp.ok} err={sp.err} />
      <form action={makeDriver} className="card row" style={{ marginBottom: 16 }}>
        <label style={{ flex: 1, minWidth: 260 }}>Ouvrir l&apos;espace livreur pour un compte existant (e-mail)<input name="email" type="email" required placeholder="livreur@exemple.com" /></label>
        <button type="submit">Ouvrir l&apos;espace livreur</button>
      </form>
      {user.isSuper ? (
        <div className="card" id="tests" style={{ marginBottom: 16 }}>
          <div className="card-title">
            <span>📞 Tests d’appel des livreurs</span>
            <a className="btn secondary" href={`/admin/livreurs?f=${f}#tests`}>Actualiser</a>
          </div>
          <p className="muted" style={{ marginTop: 0, fontSize: 13 }}>
            « Tester l’appel » fait sonner le téléphone du livreur exactement comme une nouvelle course (sonnerie, écran d’appel, Accepter / Refuser),
            sans créer de commande. Pratique à l’inscription d’un livreur ou pour vérifier son téléphone. L’application doit être installée et connectée à son compte.
          </p>
          {!tests?.length ? <p className="muted" style={{ margin: 0 }}>Aucun test pour le moment.</p> : (
            <table>
              <thead><tr><th>Livreur</th><th>Envoyé</th><th>Résultat</th><th>Délai de réponse</th></tr></thead>
              <tbody>
                {(tests as any[]).map((x) => {
                  const late = (x.status === 'sent' || x.status === 'shown') && nowMs - new Date(x.created_at).getTime() > 75_000;
                  const st = TEST_STATUS[late ? 'expired' : x.status] ?? TEST_STATUS.sent;
                  const delay = x.answered_at ? Math.round((new Date(x.answered_at).getTime() - new Date(x.created_at).getTime()) / 1000) : null;
                  return (
                    <tr key={x.id}>
                      <td>{x.profiles?.full_name ?? '—'}<div className="muted" style={{ fontSize: 12 }}>{x.profiles?.phone ?? ''}</div></td>
                      <td>{dateTime(x.created_at)}</td>
                      <td><span className={`badge ${st.cls}`}>{st.label}</span>{late && x.status === 'shown' ? <div className="muted" style={{ fontSize: 12 }}>L’appel s’est affiché</div> : null}</td>
                      <td>{delay !== null && x.status !== 'expired' ? `${delay} s` : '—'}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      ) : null}
      <div className="row" style={{ marginBottom: 12 }}>
        {Object.entries(STATUS).map(([k, v]) => <a key={k} className={`btn ${k === f ? '' : 'secondary'}`} href={`/admin/livreurs?f=${k}`}>{v.label}</a>)}
      </div>
      {!drivers?.length ? <p className="muted">Aucun livreur dans cette catégorie.</p> : null}
      {(drivers ?? []).map((d: any) => (
        <div key={d.id} className="card" style={{ marginBottom: 12 }}>
          <div className="row" style={{ justifyContent: 'space-between', alignItems: 'center' }}>
            <div className="row" style={{ alignItems: 'center' }}>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              {d.profiles?.avatar_url ? <img src={d.profiles.avatar_url} alt="" style={{ width: 64, height: 64, borderRadius: 32, objectFit: 'cover' }} /> : null}
              <div>
                <b>{d.profiles?.full_name}</b>{' '}
                {d.status === 'verified'
                  ? <span className="certified-driver"><CertifiedDriver size={18} /> Livreur certifié</span>
                  : <span className={`badge ${STATUS[d.status].cls}`}>{STATUS[d.status].label}</span>}
                <div className="muted">{d.driver_code} · {d.profiles?.email} · {d.profiles?.phone}</div>
              </div>
            </div>
            <span className="muted">Candidature du {dateTime(d.created_at)}</span>
          </div>
          <div className="cols" style={{ marginTop: 12 }}>
            <div><div className="muted">Adresse</div>{d.address}</div>
            <div><div className="muted">Région</div>{[d.city, d.province].filter(Boolean).join(', ')}</div>
            <div><div className="muted">Zones</div>{(d.zone_communes ?? []).join(', ')}</div>
            <div><div className="muted">Transport</div>{(d.driver_vehicles ?? []).map((v: any) => `${TRANSPORT[v.mode]}${v.plate_number ? ' · ' + v.plate_number : ''}${v.max_weight_kg ? ' · ' + v.max_weight_kg + ' kg' : ''}`).join(' ; ')}</div>
            <div><div className="muted">Contact d&apos;urgence</div>{d.emergency_contact_name} · {d.emergency_contact_phone}</div>
            <div><div className="muted">Paiement des gains</div>{d.payout_method} · {d.payout_account_masked}</div>
            {d.status === 'verified' ? <div><div className="muted">Activité</div>{d.is_available ? 'Disponible' : 'Indisponible'} · note {Number(d.rating).toFixed(1)} ({d.rating_count})</div> : null}
          </div>
          <div className="row" style={{ marginTop: 12 }}>
            {(d.driver_documents ?? []).map((x: any) => (
              <a key={x.id} href={signed[x.storage_path]} target="_blank" rel="noreferrer" className="btn secondary">{DOC[x.doc_type] ?? x.doc_type} ({x.status})</a>
            ))}
            {!d.driver_documents?.length ? <span className="badge bad">Aucun document</span> : null}
          </div>
          <form action={noDecision} className="row" style={{ marginTop: 12 }}>
            <input type="hidden" name="id" value={d.id} /><input type="hidden" name="f" value={f} />
            <label>Note au livreur (facultatif)<input name="note" /></label>
            {d.status !== 'verified' ? <button formAction={certify}>Certifier</button> : null}
            {d.status === 'verified' ? <button formAction={suspend} className="danger">Suspendre</button> : null}
            {d.status === 'pending_review' ? <button formAction={reject} className="secondary">Refuser</button> : null}
          </form>
          {user.isSuper ? (
            <form action={callTest} className="row" style={{ marginTop: 8 }}>
              <input type="hidden" name="id" value={d.id} /><input type="hidden" name="f" value={f} />
              <input type="hidden" name="name" value={d.profiles?.full_name ?? 'le livreur'} />
              <button type="submit" className="secondary">📞 Tester l’appel sur son téléphone</button>
            </form>
          ) : null}
        </div>
      ))}
      <p className="muted" style={{ fontSize: 13 }}>Un livreur ne peut se rendre disponible et recevoir des missions qu&apos;une fois certifié. Toute décision est inscrite au journal d&apos;audit.</p>
    </>
  );
}
