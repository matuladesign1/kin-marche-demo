# KIN MARCHÉ EN LIGNE — préparation de la version DEMO commerciale

Cette variante conserve l'application mobile et son interface, mais utilise un identifiant Android distinct (`cd.kinmarche.enligne.demo`) et un backend Supabase distinct. L'APK de production n'est pas remplacé et peut coexister sur un téléphone avec l'APK DEMO.

## Protections intégrées

- Bandeau permanent « VERSION DÉMONSTRATION — OPÉRATIONS SIMULÉES ».
- Nom « Kin Marché — DEMO », schéma d'URL et package Android distincts.
- L'écran de paiement n'appelle jamais `payments-initiate` en mode DEMO ; il simule une confirmation localement.
- Workflow de build séparé, manuel, qui refuse l'URL Supabase de production connue.

## Étape obligatoire : créer un backend DEMO isolé

Ne lancez pas le workflow tant que le projet Supabase DEMO n'est pas prêt. N'utilisez jamais les identifiants Supabase de production.

1. Créer un nouveau projet Supabase, par exemple `kin-marche-demo`.
2. Dans ce nouveau projet uniquement, appliquer les migrations du dossier `supabase/migrations/` dans l'ordre chronologique.
3. Examiner et appliquer les scripts du dossier `supabase/manual/` requis par l'application.
4. Ajouter des magasins, catégories, produits, stocks, images et comptes de test fictifs. Ne pas copier les données personnelles réelles des clients ou employés.
5. Ne configurer aucune clé de prestataire de paiement ni aucun webhook de paiement dans le projet DEMO.
6. Vérifier les politiques RLS et les fonctions avant d'exposer le projet aux démonstrateurs.

## Secrets GitHub

Dans **Settings → Secrets and variables → Actions**, créer :

- `DEMO_SUPABASE_URL` : URL du nouveau projet DEMO.
- `DEMO_SUPABASE_ANON_KEY` : clé publique/anon de ce nouveau projet.

## Construire l'APK

1. Ouvrir **Actions** dans GitHub.
2. Choisir **APK Android — DEMO commerciale**.
3. Cliquer **Run workflow**.
4. Télécharger `KinMarche-DEMO-<numéro>.apk` dans la Release `demo-<numéro>`.

## Vérifications avant présentation

Le projet DEMO doit contenir les données fictives et les fonctions serveur nécessaires (catalogue, panier, devis, création de commande, suivi, etc.). Les comptes administrateur et livreur doivent être des comptes de test avec les rôles et permissions correspondants. Les paiements sont simulés dans l'application ; aucun prestataire réel ne doit être branché.

**Important :** ces changements préparent le code et le pipeline de compilation. Ils ne constituent pas encore un APK compilé ni un backend Supabase DEMO provisionné.
